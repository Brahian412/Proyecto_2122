import pymysql
#Establecer Conección

conn = pymysql.connect(host="52.157.66.187", user="aleix", password="1Q2w3e4r5t6y", db="CHOOSE_YOUR_ADVENTURE")
cur = conn.cursor()

query = f"select * from ADVENTURE_SAVE"
cur.execute(query)
columnas = cur.description
for i in columnas:
    print(i[0])
print("-"*100)
query = f"select * from USER"
cur.execute(query)
rows = cur.fetchall()
print(rows)
print("-"*100)
columnas = cur.description

for i in columnas:
    print(i[0])

# #Insertar Query

# isbn = "7SBN"
# idtema = 2
# titulo = 'Harry Potter y la piedra filosofal'
# autor = 'Joanne Rowling'
# precio = 78
#
#
# #Al insertar los datos tienen que estar en orden para se inserten donde corresponde
# query = f"insert into llibres values ('{isbn}','{idtema}','{titulo}','{autor}','{precio}')"
#
#
# #Ejecuta la query(pero no guarda los cambios)
# cur.execute(query)
# #Guarda la query
# conn.commit()
#
#
# #Cierra la conexion para asegurarte de que se han realizado los cambios
# conn.close()